package com.facebook.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.facebook.bean.AppForm;
import com.facebook.service.AppFormService;
import com.mongodb.client.result.UpdateResult;

@RestController
@RequestMapping("/appForm-service")	
@ComponentScan("com")

public class FacebookController {
	
	@Autowired
	AppFormService appFormService;
	@PostMapping("/insert")
	public AppForm save(@RequestBody AppForm form)
	{
		return appFormService.save(form);
	}
	@GetMapping("/AppSearch")
	public List<AppForm> getByApplicationId(@PathParam("applicationId") String applicationId)
	{
		return appFormService.getApplicationId(applicationId);
	}
	/*
	 * @PutMapping("/updateApp") public UpdateResult
	 * update(@PathParam("applicationId") String applicationId) {
	 * System.out.println("cursor in controller"); return
	 * appFormService.getApplicationId(applicationId); }
	 */
	/*
	@GetMapping("/getAll")
	public List<Employee> getAll()
	{
		return employeeService.getAll();
	}
	@DeleteMapping("/delete")
	public long delete(@RequestBody Employee emp)
	{
		return employeeService.delete(emp);
	}
	@GetMapping("/getBySal")
	public List<Employee> getBySalary(@PathParam("salary") int salary)
	{
		return employeeService.getBySalary(salary);
	}
	*/
	

}
