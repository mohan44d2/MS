package com.facebook.repositery;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.facebook.bean.AppForm;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.UpdateResult;
@Repository
public class AppFormRepository {
	@Autowired
	MongoTemplate mongoTemplate;
	public AppForm save(AppForm form) {
    	System.out.println("cursor in repo");
		return mongoTemplate.save(form);
	}
	public List<AppForm> findapplicationId(String applicationId) {
		Query query=new Query(Criteria.where("applicationId").regex("^"+applicationId));
		return mongoTemplate.find(query,AppForm.class);	
		}
    public UpdateResult update(String applicationId) {
    	System.out.println("cursor in repo");
    	UpdateResult updateResult=null;
    	Query select=Query.query(Criteria.where("applicationId"));
    	Update update =new Update();
    	update.set("userdetailsForm.likesCount","6");
    	updateResult= mongoTemplate.updateMulti(select, update, "appFormUpdate");
		return updateResult;
	}
}
