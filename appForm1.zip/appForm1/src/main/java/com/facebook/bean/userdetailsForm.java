package com.facebook.bean;

import java.lang.reflect.Array;

public class userdetailsForm {
private Name name;
private String gender;
private String dob;
private String phoneNo;
private String emailid;
private String address;
private String isOnline;
private String noOfViews;
private String likesCount;
private String disLikesCount;
private String commentsCount;
private Object likes;
public Object getLikes() {
	return likes;
}
public void setLikes(Object likes) {
	this.likes = likes;
}
public Object getDisLikes() {
	return disLikes;
}
public void setDisLikes(Object disLikes) {
	this.disLikes = disLikes;
}
private Object disLikes;
private Object comments;
public Object getComments() {
	return comments;
}
public void setComments(Object comments) {
	this.comments = comments;
}
public userdetailsForm() {
	super();
	// TODO Auto-generated constructor stub
}
public userdetailsForm(Name name, String gender, String dob, String phoneNo, String emailid, String address,
		String isOnline, String noOfViews, String likesCount, String disLikesCount, String commentsCount,Array comments) {
	super();
	this.name = name;
	this.gender = gender;
	this.dob = dob;
	this.phoneNo = phoneNo;
	this.emailid = emailid;
	this.address = address;
	this.isOnline = isOnline;
	this.noOfViews = noOfViews;
	this.likesCount = likesCount;
	this.disLikesCount = disLikesCount;
	this.commentsCount = commentsCount;
	this.comments = comments;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getIsOnline() {
	return isOnline;
}
public void setIsOnline(String isOnline) {
	this.isOnline = isOnline;
}
public String getNoOfViews() {
	return noOfViews;
}
public void setNoOfViews(String noOfViews) {
	this.noOfViews = noOfViews;
}
public String getLikesCount() {
	return likesCount;
}
public void setLikesCount(String likesCount) {
	this.likesCount = likesCount;
}
public String getDisLikesCount() {
	return disLikesCount;
}
public void setDisLikesCount(String disLikesCount) {
	this.disLikesCount = disLikesCount;
}
public String getCommentsCount() {
	return commentsCount;
}
public void setCommentsCount(String commentsCount) {
	this.commentsCount = commentsCount;
}
public Name getName() {
	return name;
}
public void setName(Name name) {
	this.name = name;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
}
