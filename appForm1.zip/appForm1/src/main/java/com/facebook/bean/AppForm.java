package com.facebook.bean;

import com.facebook.bean.userdetailsForm;

public class AppForm {
private String applicationId;
private String userId;
private String createdDate;
private String lastUpated;
private String poster;
public String getPoster() {
	return poster;
}
public void setPoster(String poster) {
	this.poster = poster;
}
private userdetailsForm userdetailsForm;
public AppForm(String applicationId, String userId, String createdDate, String lastUpated,
		com.facebook.bean.userdetailsForm userdetailsForm, String gender, String dob, String phoneNo, String emailid,
		String address, String isOnline, String noOfViews, String likesCount, String disLikesCount,
		String commentsCount) {
	super();
	this.applicationId = applicationId;
	this.userId = userId;
	this.createdDate = createdDate;
	this.lastUpated = lastUpated;
	this.userdetailsForm = userdetailsForm;
}
public AppForm() {
	super();
	// TODO Auto-generated constructor stub
}
public String getApplicationId() {
	return applicationId;
}
public void setApplicationId(String applicationId) {
	this.applicationId = applicationId;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getCreatedDate() {
	return createdDate;
}
public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
}
public String getLastUpated() {
	return lastUpated;
}
public void setLastUpated(String lastUpated) {
	this.lastUpated = lastUpated;
}
public userdetailsForm getUserdetailsForm() {
	return userdetailsForm;
}
public void setUserdetailsForm(userdetailsForm userdetailsForm) {
	this.userdetailsForm = userdetailsForm;
}


}
