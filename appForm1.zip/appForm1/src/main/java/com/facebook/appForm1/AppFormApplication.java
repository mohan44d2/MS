package com.facebook.appForm1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com")
public class AppFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppFormApplication.class, args);
		System.out.println("Main Program Started");
	}

}
