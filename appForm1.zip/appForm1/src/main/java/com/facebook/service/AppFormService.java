package com.facebook.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.facebook.bean.AppForm;
import com.facebook.repositery.AppFormRepository;
import com.mongodb.client.result.UpdateResult;

@Service
public class AppFormService {
	@Autowired
    AppFormRepository appFormRepositery;
	
public AppForm save(AppForm form) {
	return appFormRepositery.save(form);
}
public List<AppForm> getApplicationId(String applicationId) {
	// TODO Auto-generated method stub
	return appFormRepositery.findapplicationId(applicationId);
}

	/*
	 * public UpdateResult update(String applicationId) {
	 * System.out.println("cursor in service"); return
	 * appFormRepositery.save(applicationId); }
	 */

}